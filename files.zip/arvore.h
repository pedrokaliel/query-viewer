#ifndef ARVORE_H
#define ARVORE_H

/* Arvore binaria de busca generica, usada no "order by nome".
   Guarda apenas ponteiros (chave e dado) para os registros das listas. */

typedef struct NoArvore {
    const char *chave;
    void *dado;
    struct NoArvore *esq, *dir;
} NoArvore;

NoArvore *arvore_inserir(NoArvore *raiz, const char *chave, void *dado);
void arvore_percorrer(NoArvore *raiz, void (*mostrar)(void *));  /* em ordem */
void arvore_liberar(NoArvore *raiz);

#endif

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "comando.h"
#include "util.h"

/* ======================= FILA ======================= */

void fila_enfileirar(Fila *f, const Comando *c)
{
    NoFila *no = malloc(sizeof(NoFila));
    no->cmd = *c;
    no->prox = NULL;
    if (f->fim) f->fim->prox = no;
    else        f->ini = no;
    f->fim = no;
}

int fila_desenfileirar(Fila *f, Comando *saida)
{
    NoFila *no = f->ini;
    if (no == NULL) return 0;
    *saida = no->cmd;
    f->ini = no->prox;
    if (f->ini == NULL) f->fim = NULL;
    free(no);
    return 1;
}

/* ================= AUXILIARES DE TEXTO ================= */

/* tira espacos do comeco e do fim */
static void aparar(char *s)
{
    int fim = strlen(s);
    while (fim > 0 && isspace((unsigned char)s[fim - 1])) fim--;
    s[fim] = '\0';
    int ini = 0;
    while (isspace((unsigned char)s[ini])) ini++;
    memmove(s, s + ini, strlen(s + ini) + 1);
}

static void minusculas(char *s)
{
    for (; *s; s++) *s = tolower((unsigned char)*s);
}

/* 'abc' -> abc */
static void tirar_aspas(char *s)
{
    int n = strlen(s);
    if (n >= 2 && s[0] == '\'' && s[n - 1] == '\'') {
        s[n - 1] = '\0';
        memmove(s, s + 1, n - 1);
    }
}

/* o texto comeca com o prefixo? (ignora maiusculas) */
static int comeca_com(const char *texto, const char *prefixo)
{
    while (*prefixo) {
        if (tolower((unsigned char)*texto) != tolower((unsigned char)*prefixo)) return 0;
        texto++;
        prefixo++;
    }
    return 1;
}

/* procura 'chave' dentro de 'texto' (ignora maiusculas) */
static char *achar(char *texto, const char *chave)
{
    for (; *texto; texto++)
        if (comeca_com(texto, chave)) return texto;
    return NULL;
}

/* Divide "a, 'b, c', 3" em itens, respeitando as aspas.
   Devolve a quantidade de itens ou -1 se houver erro. */
static int separar(const char *texto, char itens[][TAM_TEXTO], int max)
{
    int qtd = 0, j = 0, aspas = 0;

    for (int i = 0; ; i++) {
        char c = texto[i];
        if ((c == ',' && !aspas) || c == '\0') {
            itens[qtd][j] = '\0';
            aparar(itens[qtd]);
            qtd++;
            j = 0;
            if (c == '\0') break;
            if (qtd == max) return -1;       /* itens demais */
        } else {
            if (c == '\'') aspas = !aspas;
            if (j < TAM_TEXTO - 1) itens[qtd][j++] = c;
        }
    }
    return aspas ? -1 : qtd;                 /* aspas sem fechar = erro */
}

/* "campo = valor" -> campo e valor (sem aspas) */
static int separar_igual(const char *texto, char *campo, char *valor)
{
    const char *igual = strchr(texto, '=');
    if (igual == NULL) return 0;
    if (igual - texto >= TAM_TEXTO || strlen(igual + 1) >= TAM_TEXTO) return 0;

    strncpy(campo, texto, igual - texto);
    campo[igual - texto] = '\0';
    aparar(campo);

    strcpy(valor, igual + 1);
    aparar(valor);
    tirar_aspas(valor);

    return campo[0] != '\0' && valor[0] != '\0';
}

/* ================= VALIDACAO DOS COMANDOS ================= */

/* le o nome da tabela e confere se e uma das tres conhecidas.
   Devolve o ponteiro para o texto que vem depois do nome (ou NULL). */
static char *ler_tabela(Comando *c, char *p)
{
    int i = 0;
    while (*p == ' ') p++;
    while ((isalnum((unsigned char)*p) || *p == '_') && i < TAM_TEXTO - 1)
        c->tabela[i++] = tolower((unsigned char)*p++);
    c->tabela[i] = '\0';

    if (strcmp(c->tabela, "pessoa") != 0 &&
        strcmp(c->tabela, "tipo_pet") != 0 &&
        strcmp(c->tabela, "pet") != 0)
        return NULL;
    return p;
}

/* texto no formato "campo = valor" */
static int ler_where(Comando *c, const char *texto)
{
    c->tem_where = 1;
    if (!separar_igual(texto, c->where_campo, c->where_valor)) return 0;
    minusculas(c->where_campo);
    return 1;
}

/* insert into tabela(c1, c2) values(v1, v2) */
static int validar_insert(Comando *c, char *p)
{
    p = ler_tabela(c, p);
    if (p == NULL) return 0;

    while (*p == ' ') p++;
    if (*p != '(') return 0;
    char *fecha_campos = strchr(p, ')');
    if (fecha_campos == NULL) return 0;
    *fecha_campos = '\0';
    char *lista_campos = p + 1;

    char *v = achar(fecha_campos + 1, "values");
    if (v == NULL) return 0;
    v += 6;
    while (*v == ' ') v++;
    if (*v != '(') return 0;
    char *fecha_valores = strrchr(v, ')');
    if (fecha_valores == NULL || fecha_valores[1] != '\0') return 0;
    *fecha_valores = '\0';

    int nc = separar(lista_campos, c->campos, MAX_CAMPOS);
    int nv = separar(v + 1, c->valores, MAX_CAMPOS);
    if (nc <= 0 || nc != nv) return 0;

    for (int i = 0; i < nc; i++) {
        if (c->campos[i][0] == '\0') return 0;
        minusculas(c->campos[i]);
        tirar_aspas(c->valores[i]);
    }
    c->qtd = nc;
    return 1;
}

/* update tabela set c1 = v1, c2 = v2 where c3 = v3 */
static int validar_update(Comando *c, char *p)
{
    char itens[MAX_CAMPOS][TAM_TEXTO];

    p = ler_tabela(c, p);
    if (p == NULL || !comeca_com(p, " set ")) return 0;

    char *where = achar(p, " where ");
    if (where == NULL || where < p + 5) return 0;
    *where = '\0';

    int n = separar(p + 5, itens, MAX_CAMPOS);
    if (n <= 0) return 0;
    for (int i = 0; i < n; i++) {
        if (!separar_igual(itens[i], c->campos[i], c->valores[i])) return 0;
        minusculas(c->campos[i]);
    }
    c->qtd = n;
    return ler_where(c, where + 7);
}

/* delete from tabela where c1 = v1 */
static int validar_delete(Comando *c, char *p)
{
    p = ler_tabela(c, p);
    if (p == NULL) return 0;
    aparar(p);
    if (!comeca_com(p, "where ")) return 0;
    return ler_where(c, p + 6);
}

/* select * from tabela [where c1 = v1] [order by c2] */
static int validar_select(Comando *c, char *p)
{
    while (*p == ' ') p++;
    if (*p != '*') return 0;
    p++;
    while (*p == ' ') p++;
    if (!comeca_com(p, "from ")) return 0;
    p = ler_tabela(c, p + 4);
    if (p == NULL) return 0;

    char *order = achar(p, " order by ");
    if (order != NULL) {
        copiar_texto(c->order_campo, order + 10, TAM_TEXTO);
        aparar(c->order_campo);
        minusculas(c->order_campo);
        if (c->order_campo[0] == '\0' || strchr(c->order_campo, ' ')) return 0;
        *order = '\0';
    }

    aparar(p);
    if (*p == '\0') return 1;               /* sem where */
    if (!comeca_com(p, "where ")) return 0;
    return ler_where(c, p + 6);
}

int validar_comando(Comando *c)
{
    char texto[TAM_DESC];

    copiar_texto(texto, c->descricao, TAM_DESC);
    aparar(texto);
    int n = strlen(texto);
    if (n == 0 || texto[n - 1] != ';') return 0;   /* tem que terminar com ; */
    texto[n - 1] = '\0';
    aparar(texto);

    c->qtd = 0;
    c->tem_where = 0;
    c->order_campo[0] = '\0';

    if (comeca_com(texto, "insert into ")) { c->operacao = 'I'; return validar_insert(c, texto + 11); }
    if (comeca_com(texto, "update "))      { c->operacao = 'U'; return validar_update(c, texto + 6); }
    if (comeca_com(texto, "delete from ")) { c->operacao = 'D'; return validar_delete(c, texto + 11); }
    if (comeca_com(texto, "select "))      { c->operacao = 'S'; return validar_select(c, texto + 6); }
    return 0;
}

#ifndef PESSOA_H
#define PESSOA_H

#include "tipos.h"
#include "comando.h"

void      pessoa_carregar(ListaPessoa *lista, const char *arquivo);
void      pessoa_salvar(const ListaPessoa *lista, const char *arquivo);
NoPessoa *pessoa_buscar(const ListaPessoa *lista, int codigo);

/* executa um comando (insert/update/delete/select) sobre a lista de pessoas */
void      pessoa_executar(ListaPessoa *pessoas, ListaPet *pets, Comando *c);

#endif

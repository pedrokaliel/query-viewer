#ifndef TIPOS_H
#define TIPOS_H

/* Structs de dados e listas duplamente encadeadas das tres entidades. */

#define TAM_NOME      50
#define TAM_FONE      20
#define TAM_DATA      11   /* dd/mm/aaaa + '\0' */
#define TAM_ENDERECO  100

typedef struct {
    int  codigo;
    char nome[TAM_NOME];
    char fone[TAM_FONE];
    char data_nascimento[TAM_DATA];
    char endereco[TAM_ENDERECO];
} Pessoa;

typedef struct {
    int  codigo;
    char descricao[TAM_NOME];
} TipoPet;

typedef struct {
    int  codigo;
    int  codigo_pes;    /* dono do pet */
    char nome[TAM_NOME];
    int  codigo_tipo;   /* tipo do pet */
} Pet;

typedef struct NoPessoa {
    Pessoa dado;
    struct NoPessoa *ant, *prox;
} NoPessoa;
typedef struct { NoPessoa *ini, *fim; } ListaPessoa;

typedef struct NoTipoPet {
    TipoPet dado;
    struct NoTipoPet *ant, *prox;
} NoTipoPet;
typedef struct { NoTipoPet *ini, *fim; } ListaTipoPet;

typedef struct NoPet {
    Pet dado;
    struct NoPet *ant, *prox;
} NoPet;
typedef struct { NoPet *ini, *fim; } ListaPet;

#endif

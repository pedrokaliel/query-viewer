#include <stdio.h>
#include <string.h>
#include "tipos.h"
#include "comando.h"
#include "pessoa.h"
#include "tipo_pet.h"
#include "pet.h"
#include "util.h"

#define ARQ_PESSOAS   "pessoas.dat"
#define ARQ_TIPOS_PET "tipos_pet.dat"
#define ARQ_PETS      "pets.dat"

/* Le o script (de arquivo ou digitado) e coloca cada linha na fila de comandos. */
static void ler_script(Fila *fila)
{
    char linha[TAM_DESC], nome_arquivo[100];
    int opcao = 0, ordem = 0;
    FILE *entrada = stdin;

    printf("1 - ler script de um arquivo\n2 - digitar o script\nEscolha: ");
    scanf("%d", &opcao);
    while (getchar() != '\n');                 /* descarta o resto da linha */

    if (opcao == 1) {
        printf("Nome do arquivo: ");
        fgets(nome_arquivo, sizeof(nome_arquivo), stdin);
        nome_arquivo[strcspn(nome_arquivo, "\r\n")] = '\0';
        entrada = fopen(nome_arquivo, "r");
        if (entrada == NULL) {
            printf("Nao foi possivel abrir '%s'.\n", nome_arquivo);
            return;
        }
    } else {
        printf("Digite um comando por linha (linha vazia para terminar):\n");
    }

    while (fgets(linha, sizeof(linha), entrada)) {
        Comando c;
        linha[strcspn(linha, "\r\n")] = '\0';

        if (linha[0] == '\0') {
            if (entrada == stdin) break;       /* digitando: linha vazia encerra */
            continue;                          /* arquivo: ignora linhas vazias */
        }
        memset(&c, 0, sizeof(Comando));
        c.ordem = ordem++;
        copiar_texto(c.descricao, linha, TAM_DESC);
        fila_enfileirar(fila, &c);
    }

    if (entrada != stdin) fclose(entrada);
}

/* Esvazia a fila de comandos: descarta os invalidos e separa os validos por tabela. */
static void separar_comandos(Fila *entrada, Fila *f_pessoa, Fila *f_tipo, Fila *f_pet)
{
    Comando c;

    while (fila_desenfileirar(entrada, &c)) {
        if (!validar_comando(&c)) {
            printf("Comando invalido (descartado): %s\n", c.descricao);
        } else if (strcmp(c.tabela, "pessoa") == 0) {
            fila_enfileirar(f_pessoa, &c);
        } else if (strcmp(c.tabela, "tipo_pet") == 0) {
            fila_enfileirar(f_tipo, &c);
        } else {
            fila_enfileirar(f_pet, &c);
        }
    }
}

/* Entre as tres filas, devolve a que tem o comando mais antigo do script (NULL se todas vazias).
   Assim as operacoes rodam na ordem em que foram escritas, mesmo estando em filas separadas. */
static Fila *proxima_fila(Fila *f_pessoa, Fila *f_tipo, Fila *f_pet)
{
    Fila *filas[3] = {f_tipo, f_pessoa, f_pet};
    Fila *escolhida = NULL;

    for (int i = 0; i < 3; i++) {
        if (filas[i]->ini == NULL) continue;
        if (escolhida == NULL || filas[i]->ini->cmd.ordem < escolhida->ini->cmd.ordem)
            escolhida = filas[i];
    }
    return escolhida;
}

int main(void)
{
    ListaPessoa  pessoas;
    ListaTipoPet tipos;
    ListaPet     pets;
    Fila fila_comandos = {NULL, NULL};
    Fila fila_pessoa   = {NULL, NULL};
    Fila fila_tipo     = {NULL, NULL};
    Fila fila_pet      = {NULL, NULL};
    Comando c;

    /* 1. monta as listas a partir dos arquivos */
    pessoa_carregar(&pessoas, ARQ_PESSOAS);
    tipo_pet_carregar(&tipos, ARQ_TIPOS_PET);
    pet_carregar(&pets, ARQ_PETS);

    /* 2. le o script e valida/separa os comandos nas filas especificas */
    ler_script(&fila_comandos);
    separar_comandos(&fila_comandos, &fila_pessoa, &fila_tipo, &fila_pet);

    /* 3. com a fila de comandos vazia, processa as filas especificas */
    Fila *fila;
    while ((fila = proxima_fila(&fila_pessoa, &fila_tipo, &fila_pet)) != NULL) {
        fila_desenfileirar(fila, &c);
        printf("> %s\n", c.descricao);

        if (strcmp(c.tabela, "pessoa") == 0)
            pessoa_executar(&pessoas, &pets, &c);
        else if (strcmp(c.tabela, "tipo_pet") == 0)
            tipo_pet_executar(&tipos, &pets, &c);
        else
            pet_executar(&pets, &pessoas, &tipos, &c);
    }

    /* 4. grava as listas nos arquivos */
    pessoa_salvar(&pessoas, ARQ_PESSOAS);
    tipo_pet_salvar(&tipos, ARQ_TIPOS_PET);
    pet_salvar(&pets, ARQ_PETS);
    printf("\nDados salvos.\n");

    return 0;
}

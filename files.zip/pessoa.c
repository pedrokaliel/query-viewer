#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pessoa.h"
#include "pet.h"
#include "arvore.h"
#include "util.h"

/* ---------- lista duplamente encadeada ---------- */

static void inserir_fim(ListaPessoa *l, const Pessoa *p)
{
    NoPessoa *no = malloc(sizeof(NoPessoa));
    no->dado = *p;
    no->prox = NULL;
    no->ant = l->fim;
    if (l->fim) l->fim->prox = no;
    else        l->ini = no;
    l->fim = no;
}

static void remover(ListaPessoa *l, NoPessoa *no)
{
    if (no->ant) no->ant->prox = no->prox;
    else         l->ini = no->prox;
    if (no->prox) no->prox->ant = no->ant;
    else          l->fim = no->ant;
    free(no);
}

NoPessoa *pessoa_buscar(const ListaPessoa *l, int codigo)
{
    for (NoPessoa *no = l->ini; no; no = no->prox)
        if (no->dado.codigo == codigo) return no;
    return NULL;
}

/* ---------- arquivo (binario) ---------- */

void pessoa_carregar(ListaPessoa *l, const char *arquivo)
{
    Pessoa p;
    FILE *f = fopen(arquivo, "rb");

    l->ini = l->fim = NULL;
    if (f == NULL) return;               /* primeira execucao: arquivo ainda nao existe */
    while (fread(&p, sizeof(Pessoa), 1, f) == 1)
        inserir_fim(l, &p);
    fclose(f);
}

void pessoa_salvar(const ListaPessoa *l, const char *arquivo)
{
    FILE *f = fopen(arquivo, "wb");
    if (f == NULL) {
        printf("Erro ao salvar %s\n", arquivo);
        return;
    }
    for (NoPessoa *no = l->ini; no; no = no->prox)
        fwrite(&no->dado, sizeof(Pessoa), 1, f);
    fclose(f);
}

/* ---------- campos ---------- */

/* Coloca 'valor' no campo. Devolve 0 se o campo nao existe ou o valor e invalido. */
static int definir_campo(Pessoa *p, const char *campo, const char *valor)
{
    if      (strcmp(campo, "nome") == 0)            copiar_texto(p->nome, valor, TAM_NOME);
    else if (strcmp(campo, "fone") == 0)            copiar_texto(p->fone, valor, TAM_FONE);
    else if (strcmp(campo, "data_nascimento") == 0) copiar_texto(p->data_nascimento, valor, TAM_DATA);
    else if (strcmp(campo, "endereco") == 0)        copiar_texto(p->endereco, valor, TAM_ENDERECO);
    else if (strcmp(campo, "codigo") == 0 && eh_numero(valor)) p->codigo = atoi(valor);
    else return 0;
    return 1;
}

static int campo_existe(const char *campo)
{
    Pessoa teste;
    return definir_campo(&teste, campo, "0");
}

/* o campo da pessoa e igual ao valor? */
static int confere(const Pessoa *p, const char *campo, const char *valor)
{
    if (strcmp(campo, "codigo") == 0)          return p->codigo == atoi(valor);
    if (strcmp(campo, "nome") == 0)            return strcmp(p->nome, valor) == 0;
    if (strcmp(campo, "fone") == 0)            return strcmp(p->fone, valor) == 0;
    if (strcmp(campo, "data_nascimento") == 0) return strcmp(p->data_nascimento, valor) == 0;
    if (strcmp(campo, "endereco") == 0)        return strcmp(p->endereco, valor) == 0;
    return 0;
}

/* ---------- regras ---------- */

static int data_valida(const char *s)
{
    int dia, mes, ano;
    int dias[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (strlen(s) != 10 || s[2] != '/' || s[5] != '/') return 0;
    if (sscanf(s, "%d/%d/%d", &dia, &mes, &ano) != 3) return 0;
    if (ano % 4 == 0 && (ano % 100 != 0 || ano % 400 == 0)) dias[1] = 29;
    return ano >= 1900 && mes >= 1 && mes <= 12 && dia >= 1 && dia <= dias[mes - 1];
}

/* devolve a mensagem de erro ou NULL se a pessoa esta ok */
static const char *validar(const Pessoa *p)
{
    if (p->codigo <= 0 || p->nome[0] == '\0' || p->data_nascimento[0] == '\0')
        return "campos obrigatorios: codigo, nome, data_nascimento";
    if (!data_valida(p->data_nascimento))
        return "data_nascimento deve ser uma data valida dd/mm/aaaa";
    return NULL;
}

/* ---------- operacoes ---------- */

static void inserir(ListaPessoa *l, const Comando *c)
{
    Pessoa p;
    const char *erro;

    memset(&p, 0, sizeof(Pessoa));
    for (int i = 0; i < c->qtd; i++) {
        if (!definir_campo(&p, c->campos[i], c->valores[i])) {
            printf("  Erro: campo ou valor invalido (%s).\n", c->campos[i]);
            return;
        }
    }

    erro = validar(&p);
    if (erro == NULL && pessoa_buscar(l, p.codigo) != NULL)
        erro = "codigo ja cadastrado";
    if (erro != NULL) {
        printf("  Erro: %s.\n", erro);
        return;
    }

    inserir_fim(l, &p);
    printf("  Pessoa inserida.\n");
}

static void alterar(ListaPessoa *l, const Comando *c)
{
    int qtd = 0;

    for (NoPessoa *no = l->ini; no; no = no->prox) {
        Pessoa novo = no->dado;
        const char *erro;

        if (!confere(&no->dado, c->where_campo, c->where_valor)) continue;

        for (int i = 0; i < c->qtd; i++) {
            if (strcmp(c->campos[i], "codigo") == 0) {
                printf("  Erro: o codigo nao pode ser alterado.\n");
                return;
            }
            if (!definir_campo(&novo, c->campos[i], c->valores[i])) {
                printf("  Erro: campo ou valor invalido (%s).\n", c->campos[i]);
                return;
            }
        }
        erro = validar(&novo);
        if (erro != NULL) {
            printf("  Erro: %s.\n", erro);
            return;
        }
        no->dado = novo;
        qtd++;
    }
    printf("  %d registro(s) alterado(s).\n", qtd);
}

static void remover_pessoas(ListaPessoa *l, ListaPet *pets, const Comando *c)
{
    NoPessoa *no = l->ini, *prox;
    int qtd = 0;

    while (no != NULL) {
        prox = no->prox;                 /* guarda antes de possivelmente apagar o no */
        if (confere(&no->dado, c->where_campo, c->where_valor)) {
            if (pet_existe_dono(pets, no->dado.codigo)) {
                printf("  Pessoa %d nao removida: ainda possui pets.\n", no->dado.codigo);
            } else {
                remover(l, no);
                qtd++;
            }
        }
        no = prox;
    }
    printf("  %d registro(s) removido(s).\n", qtd);
}

static void mostrar(void *dado)
{
    Pessoa *p = dado;
    printf("  %d | %s | %s | %s | %s\n",
           p->codigo, p->nome, p->fone, p->data_nascimento, p->endereco);
}

static void selecionar(ListaPessoa *l, const Comando *c)
{
    NoArvore *raiz = NULL;
    int qtd = 0;

    if (c->order_campo[0] != '\0' && strcmp(c->order_campo, "nome") != 0) {
        printf("  Erro: so e possivel ordenar por nome.\n");
        return;
    }

    for (NoPessoa *no = l->ini; no; no = no->prox) {
        if (c->tem_where && !confere(&no->dado, c->where_campo, c->where_valor)) continue;
        qtd++;
        if (c->order_campo[0] != '\0')
            raiz = arvore_inserir(raiz, no->dado.nome, &no->dado);   /* arvore ordena */
        else
            mostrar(&no->dado);
    }

    arvore_percorrer(raiz, mostrar);      /* em ordem = ordenado por nome */
    arvore_liberar(raiz);
    printf("  %d registro(s) encontrado(s).\n", qtd);
}

void pessoa_executar(ListaPessoa *pessoas, ListaPet *pets, Comando *c)
{
    if (c->tem_where && !campo_existe(c->where_campo)) {
        printf("  Erro: campo '%s' nao existe em pessoa.\n", c->where_campo);
        return;
    }

    switch (c->operacao) {
        case 'I': inserir(pessoas, c);               break;
        case 'U': alterar(pessoas, c);               break;
        case 'D': remover_pessoas(pessoas, pets, c); break;
        case 'S': selecionar(pessoas, c);            break;
    }
}

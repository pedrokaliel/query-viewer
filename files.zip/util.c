#include <string.h>
#include <ctype.h>
#include "util.h"

/* strcpy seguro: nunca passa do tamanho do destino */
void copiar_texto(char *destino, const char *origem, int tamanho)
{
    strncpy(destino, origem, tamanho - 1);
    destino[tamanho - 1] = '\0';
}

int comparar_texto(const char *a, const char *b)
{
    while (*a && tolower((unsigned char)*a) == tolower((unsigned char)*b)) {
        a++;
        b++;
    }
    return tolower((unsigned char)*a) - tolower((unsigned char)*b);
}

int eh_numero(const char *s)
{
    if (*s == '\0') return 0;
    for (; *s; s++)
        if (!isdigit((unsigned char)*s)) return 0;
    return 1;
}

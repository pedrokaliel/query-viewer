#ifndef TIPO_PET_H
#define TIPO_PET_H

#include "tipos.h"
#include "comando.h"

void       tipo_pet_carregar(ListaTipoPet *lista, const char *arquivo);
void       tipo_pet_salvar(const ListaTipoPet *lista, const char *arquivo);
NoTipoPet *tipo_pet_buscar(const ListaTipoPet *lista, int codigo);

/* executa um comando sobre a lista de tipos de pet */
void       tipo_pet_executar(ListaTipoPet *tipos, ListaPet *pets, Comando *c);

#endif

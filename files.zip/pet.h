#ifndef PET_H
#define PET_H

#include "tipos.h"
#include "comando.h"

void pet_carregar(ListaPet *lista, const char *arquivo);
void pet_salvar(const ListaPet *lista, const char *arquivo);

int  pet_existe_dono(const ListaPet *lista, int codigo_pes);    /* a pessoa tem pets? */
int  pet_existe_tipo(const ListaPet *lista, int codigo_tipo);   /* existem pets deste tipo? */

/* executa um comando sobre a lista de pets (precisa das outras listas p/ validar) */
void pet_executar(ListaPet *pets, ListaPessoa *pessoas, ListaTipoPet *tipos, Comando *c);

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tipo_pet.h"
#include "pet.h"
#include "arvore.h"
#include "util.h"

/* ---------- lista duplamente encadeada ---------- */

static void inserir_fim(ListaTipoPet *l, const TipoPet *t)
{
    NoTipoPet *no = malloc(sizeof(NoTipoPet));
    no->dado = *t;
    no->prox = NULL;
    no->ant = l->fim;
    if (l->fim) l->fim->prox = no;
    else        l->ini = no;
    l->fim = no;
}

static void remover(ListaTipoPet *l, NoTipoPet *no)
{
    if (no->ant) no->ant->prox = no->prox;
    else         l->ini = no->prox;
    if (no->prox) no->prox->ant = no->ant;
    else          l->fim = no->ant;
    free(no);
}

NoTipoPet *tipo_pet_buscar(const ListaTipoPet *l, int codigo)
{
    for (NoTipoPet *no = l->ini; no; no = no->prox)
        if (no->dado.codigo == codigo) return no;
    return NULL;
}

/* ---------- arquivo (binario) ---------- */

void tipo_pet_carregar(ListaTipoPet *l, const char *arquivo)
{
    TipoPet t;
    FILE *f = fopen(arquivo, "rb");

    l->ini = l->fim = NULL;
    if (f == NULL) return;
    while (fread(&t, sizeof(TipoPet), 1, f) == 1)
        inserir_fim(l, &t);
    fclose(f);
}

void tipo_pet_salvar(const ListaTipoPet *l, const char *arquivo)
{
    FILE *f = fopen(arquivo, "wb");
    if (f == NULL) {
        printf("Erro ao salvar %s\n", arquivo);
        return;
    }
    for (NoTipoPet *no = l->ini; no; no = no->prox)
        fwrite(&no->dado, sizeof(TipoPet), 1, f);
    fclose(f);
}

/* ---------- campos ---------- */

/* "nome" e aceito como outro nome para "descricao" */
static int definir_campo(TipoPet *t, const char *campo, const char *valor)
{
    if (strcmp(campo, "nome") == 0) campo = "descricao";

    if      (strcmp(campo, "descricao") == 0) copiar_texto(t->descricao, valor, TAM_NOME);
    else if (strcmp(campo, "codigo") == 0 && eh_numero(valor)) t->codigo = atoi(valor);
    else return 0;
    return 1;
}

static int campo_existe(const char *campo)
{
    TipoPet teste;
    return definir_campo(&teste, campo, "0");
}

static int confere(const TipoPet *t, const char *campo, const char *valor)
{
    if (strcmp(campo, "nome") == 0) campo = "descricao";

    if (strcmp(campo, "codigo") == 0)    return t->codigo == atoi(valor);
    if (strcmp(campo, "descricao") == 0) return strcmp(t->descricao, valor) == 0;
    return 0;
}

static const char *validar(const TipoPet *t)
{
    if (t->codigo <= 0 || t->descricao[0] == '\0')
        return "campos obrigatorios: codigo, descricao";
    return NULL;
}

/* ---------- operacoes ---------- */

static void inserir(ListaTipoPet *l, const Comando *c)
{
    TipoPet t;
    const char *erro;

    memset(&t, 0, sizeof(TipoPet));
    for (int i = 0; i < c->qtd; i++) {
        if (!definir_campo(&t, c->campos[i], c->valores[i])) {
            printf("  Erro: campo ou valor invalido (%s).\n", c->campos[i]);
            return;
        }
    }

    erro = validar(&t);
    if (erro == NULL && tipo_pet_buscar(l, t.codigo) != NULL)
        erro = "codigo ja cadastrado";
    if (erro != NULL) {
        printf("  Erro: %s.\n", erro);
        return;
    }

    inserir_fim(l, &t);
    printf("  Tipo de pet inserido.\n");
}

static void alterar(ListaTipoPet *l, const Comando *c)
{
    int qtd = 0;

    for (NoTipoPet *no = l->ini; no; no = no->prox) {
        TipoPet novo = no->dado;
        const char *erro;

        if (!confere(&no->dado, c->where_campo, c->where_valor)) continue;

        for (int i = 0; i < c->qtd; i++) {
            if (strcmp(c->campos[i], "codigo") == 0) {
                printf("  Erro: o codigo nao pode ser alterado.\n");
                return;
            }
            if (!definir_campo(&novo, c->campos[i], c->valores[i])) {
                printf("  Erro: campo ou valor invalido (%s).\n", c->campos[i]);
                return;
            }
        }
        erro = validar(&novo);
        if (erro != NULL) {
            printf("  Erro: %s.\n", erro);
            return;
        }
        no->dado = novo;
        qtd++;
    }
    printf("  %d registro(s) alterado(s).\n", qtd);
}

static void remover_tipos(ListaTipoPet *l, ListaPet *pets, const Comando *c)
{
    NoTipoPet *no = l->ini, *prox;
    int qtd = 0;

    while (no != NULL) {
        prox = no->prox;
        if (confere(&no->dado, c->where_campo, c->where_valor)) {
            if (pet_existe_tipo(pets, no->dado.codigo)) {
                printf("  Tipo %d nao removido: existem pets deste tipo.\n", no->dado.codigo);
            } else {
                remover(l, no);
                qtd++;
            }
        }
        no = prox;
    }
    printf("  %d registro(s) removido(s).\n", qtd);
}

static void mostrar(void *dado)
{
    TipoPet *t = dado;
    printf("  %d | %s\n", t->codigo, t->descricao);
}

static void selecionar(ListaTipoPet *l, const Comando *c)
{
    NoArvore *raiz = NULL;
    int qtd = 0;

    if (c->order_campo[0] != '\0' &&
        strcmp(c->order_campo, "nome") != 0 && strcmp(c->order_campo, "descricao") != 0) {
        printf("  Erro: so e possivel ordenar por nome.\n");
        return;
    }

    for (NoTipoPet *no = l->ini; no; no = no->prox) {
        if (c->tem_where && !confere(&no->dado, c->where_campo, c->where_valor)) continue;
        qtd++;
        if (c->order_campo[0] != '\0')
            raiz = arvore_inserir(raiz, no->dado.descricao, &no->dado);
        else
            mostrar(&no->dado);
    }

    arvore_percorrer(raiz, mostrar);
    arvore_liberar(raiz);
    printf("  %d registro(s) encontrado(s).\n", qtd);
}

void tipo_pet_executar(ListaTipoPet *tipos, ListaPet *pets, Comando *c)
{
    if (c->tem_where && !campo_existe(c->where_campo)) {
        printf("  Erro: campo '%s' nao existe em tipo_pet.\n", c->where_campo);
        return;
    }

    switch (c->operacao) {
        case 'I': inserir(tipos, c);               break;
        case 'U': alterar(tipos, c);               break;
        case 'D': remover_tipos(tipos, pets, c);   break;
        case 'S': selecionar(tipos, c);            break;
    }
}

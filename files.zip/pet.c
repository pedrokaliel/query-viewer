#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pet.h"
#include "pessoa.h"
#include "tipo_pet.h"
#include "arvore.h"
#include "util.h"

/* ---------- lista duplamente encadeada ---------- */

static void inserir_fim(ListaPet *l, const Pet *p)
{
    NoPet *no = malloc(sizeof(NoPet));
    no->dado = *p;
    no->prox = NULL;
    no->ant = l->fim;
    if (l->fim) l->fim->prox = no;
    else        l->ini = no;
    l->fim = no;
}

static void remover(ListaPet *l, NoPet *no)
{
    if (no->ant) no->ant->prox = no->prox;
    else         l->ini = no->prox;
    if (no->prox) no->prox->ant = no->ant;
    else          l->fim = no->ant;
    free(no);
}

static NoPet *buscar(const ListaPet *l, int codigo)
{
    for (NoPet *no = l->ini; no; no = no->prox)
        if (no->dado.codigo == codigo) return no;
    return NULL;
}

int pet_existe_dono(const ListaPet *l, int codigo_pes)
{
    for (NoPet *no = l->ini; no; no = no->prox)
        if (no->dado.codigo_pes == codigo_pes) return 1;
    return 0;
}

int pet_existe_tipo(const ListaPet *l, int codigo_tipo)
{
    for (NoPet *no = l->ini; no; no = no->prox)
        if (no->dado.codigo_tipo == codigo_tipo) return 1;
    return 0;
}

/* ---------- arquivo (binario) ---------- */

void pet_carregar(ListaPet *l, const char *arquivo)
{
    Pet p;
    FILE *f = fopen(arquivo, "rb");

    l->ini = l->fim = NULL;
    if (f == NULL) return;
    while (fread(&p, sizeof(Pet), 1, f) == 1)
        inserir_fim(l, &p);
    fclose(f);
}

void pet_salvar(const ListaPet *l, const char *arquivo)
{
    FILE *f = fopen(arquivo, "wb");
    if (f == NULL) {
        printf("Erro ao salvar %s\n", arquivo);
        return;
    }
    for (NoPet *no = l->ini; no; no = no->prox)
        fwrite(&no->dado, sizeof(Pet), 1, f);
    fclose(f);
}

/* ---------- campos ---------- */

/* O enunciado usa nomes diferentes para o mesmo campo; aceitamos todos. */
static const char *canonico(const char *campo)
{
    if (strcmp(campo, "codigo_cli") == 0)      return "codigo_pes";
    if (strcmp(campo, "codigo_tipo_pet") == 0) return "codigo_tipo";
    return campo;
}

static int definir_campo(Pet *p, const char *campo, const char *valor)
{
    campo = canonico(campo);

    if (strcmp(campo, "nome") == 0) {
        copiar_texto(p->nome, valor, TAM_NOME);
        return 1;
    }
    if (!eh_numero(valor)) return 0;

    if      (strcmp(campo, "codigo") == 0)      p->codigo = atoi(valor);
    else if (strcmp(campo, "codigo_pes") == 0)  p->codigo_pes = atoi(valor);
    else if (strcmp(campo, "codigo_tipo") == 0) p->codigo_tipo = atoi(valor);
    else return 0;
    return 1;
}

static int campo_existe(const char *campo)
{
    Pet teste;
    return definir_campo(&teste, campo, "0");
}

static int confere(const Pet *p, const char *campo, const char *valor)
{
    campo = canonico(campo);

    if (strcmp(campo, "codigo") == 0)      return p->codigo == atoi(valor);
    if (strcmp(campo, "codigo_pes") == 0)  return p->codigo_pes == atoi(valor);
    if (strcmp(campo, "codigo_tipo") == 0) return p->codigo_tipo == atoi(valor);
    if (strcmp(campo, "nome") == 0)        return strcmp(p->nome, valor) == 0;
    return 0;
}

/* ---------- regras ---------- */

/* devolve a mensagem de erro ou NULL se o pet esta ok */
static const char *validar(const Pet *p, const ListaPessoa *pessoas, const ListaTipoPet *tipos)
{
    if (p->codigo <= 0 || p->codigo_pes <= 0 || p->codigo_tipo <= 0 || p->nome[0] == '\0')
        return "campos obrigatorios: codigo, codigo_pes, nome, codigo_tipo";
    if (pessoa_buscar(pessoas, p->codigo_pes) == NULL)
        return "codigo_pes nao pertence a nenhuma pessoa cadastrada";
    if (tipo_pet_buscar(tipos, p->codigo_tipo) == NULL)
        return "codigo_tipo nao pertence a nenhum tipo de pet cadastrado";
    return NULL;
}

/* ---------- operacoes ---------- */

static void inserir(ListaPet *l, const ListaPessoa *pessoas, const ListaTipoPet *tipos, const Comando *c)
{
    Pet p;
    const char *erro;

    memset(&p, 0, sizeof(Pet));
    for (int i = 0; i < c->qtd; i++) {
        if (!definir_campo(&p, c->campos[i], c->valores[i])) {
            printf("  Erro: campo ou valor invalido (%s).\n", c->campos[i]);
            return;
        }
    }

    erro = validar(&p, pessoas, tipos);
    if (erro == NULL && buscar(l, p.codigo) != NULL)
        erro = "codigo ja cadastrado";
    if (erro != NULL) {
        printf("  Erro: %s.\n", erro);
        return;
    }

    inserir_fim(l, &p);
    printf("  Pet inserido.\n");
}

static void alterar(ListaPet *l, const ListaPessoa *pessoas, const ListaTipoPet *tipos, const Comando *c)
{
    int qtd = 0;

    for (NoPet *no = l->ini; no; no = no->prox) {
        Pet novo = no->dado;
        const char *erro;

        if (!confere(&no->dado, c->where_campo, c->where_valor)) continue;

        for (int i = 0; i < c->qtd; i++) {
            if (strcmp(c->campos[i], "codigo") == 0) {
                printf("  Erro: o codigo nao pode ser alterado.\n");
                return;
            }
            if (!definir_campo(&novo, c->campos[i], c->valores[i])) {
                printf("  Erro: campo ou valor invalido (%s).\n", c->campos[i]);
                return;
            }
        }
        erro = validar(&novo, pessoas, tipos);   /* garante dono e tipo validos */
        if (erro != NULL) {
            printf("  Erro: %s.\n", erro);
            return;
        }
        no->dado = novo;
        qtd++;
    }
    printf("  %d registro(s) alterado(s).\n", qtd);
}

static void remover_pets(ListaPet *l, const Comando *c)
{
    NoPet *no = l->ini, *prox;
    int qtd = 0;

    while (no != NULL) {
        prox = no->prox;
        if (confere(&no->dado, c->where_campo, c->where_valor)) {
            remover(l, no);
            qtd++;
        }
        no = prox;
    }
    printf("  %d registro(s) removido(s).\n", qtd);
}

static void mostrar(void *dado)
{
    Pet *p = dado;
    printf("  %d | dono: %d | %s | tipo: %d\n", p->codigo, p->codigo_pes, p->nome, p->codigo_tipo);
}

static void selecionar(ListaPet *l, const Comando *c)
{
    NoArvore *raiz = NULL;
    int qtd = 0;

    if (c->order_campo[0] != '\0' && strcmp(c->order_campo, "nome") != 0) {
        printf("  Erro: so e possivel ordenar por nome.\n");
        return;
    }

    for (NoPet *no = l->ini; no; no = no->prox) {
        if (c->tem_where && !confere(&no->dado, c->where_campo, c->where_valor)) continue;
        qtd++;
        if (c->order_campo[0] != '\0')
            raiz = arvore_inserir(raiz, no->dado.nome, &no->dado);
        else
            mostrar(&no->dado);
    }

    arvore_percorrer(raiz, mostrar);
    arvore_liberar(raiz);
    printf("  %d registro(s) encontrado(s).\n", qtd);
}

void pet_executar(ListaPet *pets, ListaPessoa *pessoas, ListaTipoPet *tipos, Comando *c)
{
    if (c->tem_where && !campo_existe(c->where_campo)) {
        printf("  Erro: campo '%s' nao existe em pet.\n", c->where_campo);
        return;
    }

    switch (c->operacao) {
        case 'I': inserir(pets, pessoas, tipos, c);  break;
        case 'U': alterar(pets, pessoas, tipos, c);  break;
        case 'D': remover_pets(pets, c);             break;
        case 'S': selecionar(pets, c);               break;
    }
}

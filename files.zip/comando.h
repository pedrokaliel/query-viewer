#ifndef COMANDO_H
#define COMANDO_H

#define TAM_DESC    300
#define TAM_TEXTO   100
#define MAX_CAMPOS  10

/* Um comando: guarda o texto original e, depois de validado,
   as partes ja separadas (operacao, tabela, campos, valores...). */
typedef struct {
    int  ordem;                        /* posicao do comando no script */
    char descricao[TAM_DESC];          /* texto original do comando */
    char operacao;                     /* 'I' insert, 'U' update, 'D' delete, 'S' select */
    char tabela[TAM_TEXTO];            /* pessoa, tipo_pet ou pet */
    int  qtd;                          /* qtd de campos (insert/update) */
    char campos[MAX_CAMPOS][TAM_TEXTO];
    char valores[MAX_CAMPOS][TAM_TEXTO];
    int  tem_where;
    char where_campo[TAM_TEXTO];
    char where_valor[TAM_TEXTO];
    char order_campo[TAM_TEXTO];       /* vazio = sem order by */
} Comando;

/* Fila de comandos (lista encadeada com inicio e fim) */
typedef struct NoFila {
    Comando cmd;
    struct NoFila *prox;
} NoFila;

typedef struct {
    NoFila *ini, *fim;
} Fila;

void fila_enfileirar(Fila *f, const Comando *c);
int  fila_desenfileirar(Fila *f, Comando *saida);   /* 0 se a fila estava vazia */

/* Devolve 1 se o comando segue um dos formatos aceitos (e preenche suas partes). */
int validar_comando(Comando *c);

#endif

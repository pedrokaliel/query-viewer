#ifndef UTIL_H
#define UTIL_H

void copiar_texto(char *destino, const char *origem, int tamanho);
int  comparar_texto(const char *a, const char *b);   /* ignora maiusculas/minusculas */
int  eh_numero(const char *s);                       /* so digitos e nao vazio */

#endif
